# Front-end build

The browser assets are no longer hand-maintained files at the project root.
`src/` is the source, `package.json` + `build.mjs` (esbuild) turn it into
`static/dist/` and a generated `index.html`.

```
src/index.html   template  ->  index.html          (generated, gitignored)
src/js/main.js   entry     ->  static/dist/app-<hash>.js
src/js/portal.js  imported by main.js
src/css/style.css imported by main.js  ->  static/dist/app-<hash>.css
```

## Commands

```bash
npm install        # once (Node >= 18); esbuild is the only dependency
npm run dev        # watch src/, rebuild on save (unminified + sourcemaps)
npm run build      # production: minified, content-hashed filenames
npm run clean      # delete static/dist and the generated index.html
npm start          # build, then run the Flask dev server
```

Flask serves `index.html` from the project root and `static/dist/` through its
normal static handler, so `python3 app.py` still works — it just needs a build
to have run first. If it hasn't, `/` returns a 500 page telling you to run one.

## What changed in the app

- `script.js` and `portal.js` moved into `src/js/` and are ES modules now:
  `main.js` does `import { Portal } from "./portal.js"` instead of reaching for
  the `window.Portal` global, and `import "../css/style.css"` pulls the
  stylesheet into the same build.
- `index.html` no longer hardcodes `/style.css`, `/script.js`, `/portal.js`.
  The template carries `%CSS%` / `%JS%` placeholders that the build fills in
  with the hashed filenames — which is what lets the assets be cached
  aggressively without ever serving a stale bundle.
- The `@app.route("/<any(script.js, portal.js, style.css):asset>")` route in
  `app.py` is gone; that list of filenames was the static part.
- `.gitignore` picks up `node_modules/`, `static/dist/` and `index.html`.

## Deploying

`static/dist/` and `index.html` are build output, not source, so the deploy has
to build before restarting Gunicorn:

```bash
cd /home/formed/www
git pull
venv/bin/pip install -r requirements.txt
npm ci && npm run build
sudo systemctl restart formed
```

`formed.service` itself needs no changes. If you'd rather not install Node on
the server, run `npm run build` in CI and ship `static/dist/` + `index.html` as
artifacts.
